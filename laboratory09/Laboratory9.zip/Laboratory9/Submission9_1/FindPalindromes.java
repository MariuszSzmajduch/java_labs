/**
 * JP2 lab 9 driver program
 * Read in a file containing one word per line,
 * find palindrome words and print out list of
 * all palindromes found at the end.
 * @author jsinger
 */
public class FindPalindromes {

    /**
     * take a single param - the filename
     * containing list of candidate words, 
     * detect palindrome words and print out a 
     * list of these palindromes
     */
    public static void main(String [] args) {
        
        // insert your code here...
        
    }

}
