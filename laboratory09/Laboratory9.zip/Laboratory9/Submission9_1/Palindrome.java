/**
 * JP2 lab 9
 * A palindrome reads the same forwards and
 * backwards, e.g. 'oxo' or 'racecar'
 * @author jsinger
 */
public class Palindrome {
    // fill in the details here
}
