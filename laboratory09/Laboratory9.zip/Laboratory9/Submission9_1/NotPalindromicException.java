/**
 * JP2 lab 9
 * This error is thrown to show that 'word'
 * is not a palindrome
 * @author jsinger
 */
public class NotPalindromicException /* ?? */ {
    // add your code here
}